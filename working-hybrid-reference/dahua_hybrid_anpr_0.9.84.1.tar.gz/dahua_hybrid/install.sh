#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="${SCRIPT_DIR}/dahua"
COMPONENTS_DIR="/config/custom_components"
BACKUPS_DIR="/config/dahua_backups"
TARGET_DIR="${COMPONENTS_DIR}/dahua"
STAMP="$(date +%Y%m%d_%H%M%S)"
STAGE_DIR="/config/dahua_hybrid_stage_${STAMP}"
BACKUP_DIR="${BACKUPS_DIR}/dahua_${STAMP}"

if [ ! -f "${SOURCE_DIR}/manifest.json" ]; then
  echo "ERROR: Package is missing dahua/manifest.json"
  exit 1
fi

if [ ! -f "${SOURCE_DIR}/sensor.py" ]; then
  echo "ERROR: Package is missing dahua/sensor.py"
  exit 1
fi

echo "Validating Python and JSON files..."
python3 - "${SOURCE_DIR}" <<'PY'
import ast
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
for path in root.rglob("*.py"):
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
json.loads((root / "manifest.json").read_text(encoding="utf-8"))
json.loads((root / "translations" / "en.json").read_text(encoding="utf-8"))
print("Validation passed")
PY

mkdir -p "${COMPONENTS_DIR}"
mkdir -p "${BACKUPS_DIR}"

# Old integration backups cannot remain under custom_components because Home
# Assistant will try to load them as integrations.
for OLD_DIR in \
  "${COMPONENTS_DIR}"/dahua_backup_* \
  "${COMPONENTS_DIR}"/dahua_install_*
do
  if [ -d "${OLD_DIR}" ]; then
    mv "${OLD_DIR}" "${BACKUPS_DIR}/"
  fi
done

cp -a "${SOURCE_DIR}" "${STAGE_DIR}"

if [ -d "${TARGET_DIR}" ]; then
  echo "Backing up current Dahua integration to:"
  echo "${BACKUP_DIR}"
  mv "${TARGET_DIR}" "${BACKUP_DIR}"
fi

if ! mv "${STAGE_DIR}" "${TARGET_DIR}"; then
  echo "ERROR: Installation failed. Restoring previous integration."
  if [ -d "${BACKUP_DIR}" ] && [ ! -d "${TARGET_DIR}" ]; then
    mv "${BACKUP_DIR}" "${TARGET_DIR}"
  fi
  exit 1
fi

echo
echo "Dahua Hybrid ANPR installed successfully."
echo "Installed version:"
grep '"version"' "${TARGET_DIR}/manifest.json"
echo
echo "Restart Home Assistant with:"
echo "ha core restart"
