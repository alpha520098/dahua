Dahua Hybrid ANPR 0.9.84.1
============================

Purpose
-------
This package uses the user's working Dahua 0.9.84-based integration and keeps
its Smart Motion Human/Vehicle, Face Detection and Traffic behaviour. It adds:

- sensor.<camera>_license_plate
- binary_sensor.<camera>_authorized_vehicle
- dahua_anpr_recognized Home Assistant event
- Authorized license plates setting
- Authorized Vehicle hold-time setting

Installation
------------
1. Put dahua_hybrid_anpr_0.9.84.1.tar.gz in /config.
2. In the Home Assistant Terminal, paste:

   mkdir -p /config/dahua_hybrid_package
   tar -xzf /config/dahua_hybrid_anpr_0.9.84.1.tar.gz -C /config/dahua_hybrid_package --strip-components=1
   bash /config/dahua_hybrid_package/install.sh
   ha core restart

Configuration
-------------
After restarting, open Settings > Devices & services > Dahua. Select Configure
for the ANPR-capable camera entry. Enter authorized plates separated by commas,
for example:

ABC123, XYZ789

The default Authorized Vehicle hold time is 60 seconds.

Testing
-------
In Developer Tools > Events, listen for:

dahua_anpr_recognized

Drive a plate through the configured Dahua ANPR detection region. The License
Plate sensor changes only when the camera or NVR supplies recognized plate text.
This integration does not perform OCR on snapshots itself.

Safety
------
The installer backs up the current integration under /config/dahua_backups.
It deliberately keeps backups outside /config/custom_components so Home
Assistant does not attempt to load the backup as a second integration.

HACS warning
------------
Do not update or redownload Dahua through HACS after installing this package.
HACS will overwrite the hybrid files.
